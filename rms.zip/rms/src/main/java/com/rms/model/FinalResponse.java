package com.rms.model;

import lombok.Data;

@Data
public class FinalResponse {
	private Boolean status;
	private Object data;
	private String message;

}
